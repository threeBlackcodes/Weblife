var phonecatApp = angular.module('teste', []);


phonecatApp.controller('TesteController', function TesteController($scope) {


    $scope.perguntas = ("fwef,ewfwef");
    console.log(QCon.RequireData("teste.php"));
    $scope.alternativas = ($scope.perguntas).split(",");
});
